package com.niit.tech.mvc.service;

public interface HelloWorldService {

	public void printHello();
}
