package com.niit.tech.mvc.service.impl;

import com.niit.tech.mvc.service.HelloWorldService;

public class HelloWorldServiceImpl implements HelloWorldService {

	public void printHello() {
		System.out.println("hello world");
	}

}
